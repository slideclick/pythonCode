while not iterator.done():
    item = iterator.next()
    # do something with the item
