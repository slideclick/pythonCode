import tkinter

class EmptyFrame(tkinter.Frame):
    pass

root = tkinter.Tk()
EmptyFrame(master=root).mainloop()
