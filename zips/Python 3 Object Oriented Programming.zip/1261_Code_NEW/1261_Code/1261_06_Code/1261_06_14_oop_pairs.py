c = a + b
c = a.add(b)

l[0] = 5
l.insert(0, 5)

d[key] = value
d.setitem(key, value)

for x in alist:
    #do something with x
it = alist.iterator()
while it.has_next():
    x = it.next()
    #do something with x

