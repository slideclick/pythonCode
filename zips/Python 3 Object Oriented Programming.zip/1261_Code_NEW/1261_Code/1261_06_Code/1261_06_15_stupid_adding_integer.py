class SillyInt(int):
    def __add__(self, num):
        return 0
