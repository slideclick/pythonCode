template = "Hello {}, you are currently {}."
print(template.format('Dusty', 'writing'))
