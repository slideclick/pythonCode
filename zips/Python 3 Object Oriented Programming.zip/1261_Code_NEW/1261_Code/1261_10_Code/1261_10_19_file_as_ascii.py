file = open('filename', encoding='ascii', errors='replace')
print(file.read())
