template = "Hello {0}, you are {1}. Your name is {0}."
print(template.format('Dusty', 'writing'))
