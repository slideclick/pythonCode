template = "Hello {}, you are {}. Your name is {0}."
print(template.format('Dusty', 'writing'))
