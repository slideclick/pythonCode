def test_int_float():
    assert 1 == 1.0
