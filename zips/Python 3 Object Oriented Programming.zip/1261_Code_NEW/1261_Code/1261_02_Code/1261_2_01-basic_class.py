class MyFirstClass:
    pass
