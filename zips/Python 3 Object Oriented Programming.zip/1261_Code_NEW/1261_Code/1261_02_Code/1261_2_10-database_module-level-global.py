class Database:
    # the database implementation
    pass

database = Database()
