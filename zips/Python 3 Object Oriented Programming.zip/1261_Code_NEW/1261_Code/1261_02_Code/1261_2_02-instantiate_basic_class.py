class MyFirstClass:
    pass

a = MyFirstClass()
b = MyFirstClass()
print(a)
print(b)
