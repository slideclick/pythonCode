class Agent:
    def __init__(self):
        self.property_list = []

    def display_properties():
        for property in self.property_list:
            property.display()
